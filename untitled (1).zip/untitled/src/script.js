document.addEventListener("DOMContentLoaded", () => {
    // Dark and Light Mode Toggle
    const themeToggle = document.getElementById("toggle-theme");
    const body = document.body;

    function loadThemePreference() {
        const userPreference = localStorage.getItem("theme");
        if (userPreference === "dark") {
            body.classList.add("dark");
            themeToggle.textContent = "☀";
        } else {
            body.classList.remove("dark");
            themeToggle.textContent = "🌙";
        }
    }

    themeToggle.addEventListener("click", () => {
        body.classList.toggle("dark");
        const isDarkMode = body.classList.contains("dark");
        localStorage.setItem("theme", isDarkMode ? "dark" : "light");
        themeToggle.textContent = isDarkMode ? "☀" : "🌙";
    });

    loadThemePreference();

    // Password Generator
    const passwordInput = document.getElementById("generated-password");
    const lengthDisplay = document.getElementById("length-display");
    const passwordLength = document.getElementById("password-length");
    const crackTimeEstimate = document.getElementById("crack-time-estimate");
    const passwordStrength = document.getElementById("password-strength");

    passwordLength.addEventListener("input", () => {
        lengthDisplay.textContent = passwordLength.value;
    });

    function calculateCrackTime(password) {
        const complexity = password.length * 100;
        const seconds = Math.pow(2, complexity) / 1e9;
        const years = seconds / (3600 * 24 * 365);
        return years > 1 ? `${years.toFixed(2)} years` : `${(years * 12).toFixed(2)} months`;
    }

    function evaluatePasswordStrength(password) {
        let strength = 0;
        if (password.length >= 8) strength++; // Length check
        if (/[A-Z]/.test(password)) strength++; // Uppercase letter check
        if (/[a-z]/.test(password)) strength++; // Lowercase letter check
        if (/[0-9]/.test(password)) strength++; // Number check
        if (/[\W_]/.test(password)) strength++; // Symbol check

        switch (strength) {
            case 1:
            case 2:
                return "Weak";
            case 3:
                return "Moderate";
            case 4:
                return "Strong";
            case 5:
                return "Very Strong";
            default:
                return "Very Weak";
        }
    }

    function generatePassword() {
        const length = passwordLength.value;
        let charset = "";
        if (document.getElementById("include-uppercase").checked) charset += "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        if (document.getElementById("include-lowercase").checked) charset += "abcdefghijklmnopqrstuvwxyz";
        if (document.getElementById("include-numbers").checked) charset += "0123456789";
        if (document.getElementById("include-symbols").checked) charset += "!@#$%^&*()_-+=<>?";
        if (document.getElementById("include-emojis").checked) charset += "😀😃😄😁😆😅😂🤣😊😇";

        let password = "";
        for (let i = 0; i < length; i++) {
            password += charset.charAt(Math.floor(Math.random() * charset.length));
        }

        passwordInput.value = password;
        crackTimeEstimate.textContent = `Estimated Crack Time: ${calculateCrackTime(password)}`;
        passwordStrength.textContent = `Password Strength: ${evaluatePasswordStrength(password)}`;
    }

    document.getElementById("generate-password").addEventListener("click", generatePassword);

    // Show/Hide Password
    const showHideButton = document.getElementById("show-hide-password");
    showHideButton.addEventListener("click", () => {
        const type = passwordInput.type === "password" ? "text" : "password";
        passwordInput.type = type;
        showHideButton.textContent = type === "password" ? "👁" : "🙈";
    });

    // Copy Password
    document.getElementById("copy-password").addEventListener("click", () => {
        navigator.clipboard.writeText(passwordInput.value);
        alert("Password copied to clipboard!");
    });

    // Voice Recognition
    const voiceInputButton = document.getElementById("voice-input");
    const voiceFeedback = document.getElementById("voice-feedback");

    if ("webkitSpeechRecognition" in window) {
        const recognition = new webkitSpeechRecognition();
        recognition.continuous = false;
        recognition.interimResults = false;
        recognition.lang = "en-US";

        voiceInputButton.addEventListener("click", () => {
            recognition.start();
            voiceFeedback.textContent = "Listening...";
        });

        recognition.onresult = (event) => {
            const spokenText = event.results[0][0].transcript.trim();
            passwordInput.value = spokenText;
            voiceFeedback.textContent = "Password captured!";
        };

        recognition.onerror = (event) => {
            voiceFeedback.textContent = `Error: ${event.error}`;
        };

        recognition.onend = () => {
            voiceFeedback.textContent = "Click the mic to speak your password...";
        };
    } else {
        voiceFeedback.textContent = "Voice recognition is not supported in this browser.";
        voiceInputButton.disabled = true;
    }
});
